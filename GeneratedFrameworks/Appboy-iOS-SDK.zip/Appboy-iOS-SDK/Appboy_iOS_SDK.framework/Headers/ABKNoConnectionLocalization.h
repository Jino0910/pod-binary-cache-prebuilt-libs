#import <Foundation/Foundation.h>

@interface ABKNoConnectionLocalization : NSObject

+ (NSString *)getNoConnectionLocalizedString;

@end
