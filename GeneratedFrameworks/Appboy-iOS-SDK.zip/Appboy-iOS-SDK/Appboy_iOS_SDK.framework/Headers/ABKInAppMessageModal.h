#import "ABKInAppMessageImmersive.h"

/*
 * Braze Public API: ABKInAppMessageModal
 */
NS_ASSUME_NONNULL_BEGIN
@interface ABKInAppMessageModal : ABKInAppMessageImmersive

@end
NS_ASSUME_NONNULL_END
