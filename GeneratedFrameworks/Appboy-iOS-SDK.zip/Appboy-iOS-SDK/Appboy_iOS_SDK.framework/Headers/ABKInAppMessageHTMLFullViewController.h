#import <UIKit/UIKit.h>
#import "ABKInAppMessageHTMLBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ABKInAppMessageHTMLFullViewController : ABKInAppMessageHTMLBaseViewController

@end
NS_ASSUME_NONNULL_END
