// Moved to root of objectivec directory, shim to keep anyone's imports working.
#import "GPBAny.pbobjc.h"
